Python Verion: 3.4.3

Path for saving extracted files:
1) copy the path where you want to save the txt files.
2) provide the copied path in "main_program.py" in 'textfiles_path'
