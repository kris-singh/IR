Copy your index.sh/query.sh files to this directory, and modify them so that your Java program can be called under toy_example folder, then run:
./grader.sh
